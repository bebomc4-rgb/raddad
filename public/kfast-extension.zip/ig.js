// K FAST AI — جوّا إنستغرام: بيقرا التعليقات الجديدة على آخر منشوراتك وبيرد عليها ببطء متل البشر
(() => {
  const APP_ID = '936619743392459';
  const cookie = n => (document.cookie.match('(?:^|; )' + n + '=([^;]*)') || [])[1] || '';
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const send = m => chrome.runtime.sendMessage(m).catch(() => {});
  let busy = false;

  async function ig(path, opts = {}) {
    const r = await fetch('https://www.instagram.com' + path, {
      credentials: 'include', ...opts,
      headers: { 'x-ig-app-id': APP_ID, 'x-csrftoken': cookie('csrftoken'), 'x-requested-with': 'XMLHttpRequest', ...(opts.headers || {}) }
    });
    if (r.status === 429) throw new Error('إنستغرام طلب نوقّف شوي (429) — رح نرجع بعدين');
    const d = await r.json().catch(() => ({}));
    if (!r.ok || d.status === 'fail') throw new Error(d.message || 'إنستغرام ردّ ' + r.status);
    return d;
  }

  async function sendDM({ users, thread, text }) {
    const body = new URLSearchParams({ action: 'send_item', text, client_context: String(Date.now()) + Math.floor(Math.random() * 1e6), mutation_token: crypto.randomUUID() });
    if (thread) body.set('thread_ids', JSON.stringify([String(thread)]));
    else body.set('recipient_users', JSON.stringify([users.map(String)]));
    return ig('/api/v1/direct_v2/threads/broadcast/text/', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body });
  }

  async function cycle() {
    if (busy) return; busy = true;
    try {
      const st = await chrome.storage.local.get({ enabled: false, perHour: 20, seen: [], startedAt: 0, lastReplyAt: 0, hourly: [], dmOnComment: true, dmReply: true, seenDM: [] });
      if (!st.enabled) return;
      const uid = cookie('ds_user_id');
      if (!uid) return send({ cmd: 'status', text: '✗ سجّل دخول على إنستغرام بهالمتصفح' });
      const now = Date.now();
      let startedAt = st.startedAt;
      if (!startedAt) { startedAt = Math.floor(now / 1000); await chrome.storage.local.set({ startedAt }); } // بس التعليقات الجديدة من هلأ
      const hourly = st.hourly.filter(t => now - t < 3600e3);
      if (hourly.length >= st.perHour) return send({ cmd: 'status', text: `⏳ وصلنا الحد (${st.perHour} بالساعة) — عم نستنّى` });
      if (now - st.lastReplyAt < 60e3 + Math.random() * 60e3) return send({ cmd: 'status', text: '✅ شغّال — عم يستنّى شوي بين الردود' });

      // الرسائل الخاصة: رد على آخر رسالة جديدة من زبون
      if (st.dmReply) {
        const seenDM = new Set(st.seenDM);
        const inbox = await ig('/api/v1/direct_v2/inbox/?persistentBadging=true&folder=&limit=10&thread_message_limit=10');
        for (const th of inbox.inbox?.threads || []) {
          const items = th.items || []; // الأحدث أول
          const last = items[0];
          if (!last || String(last.user_id) === String(uid) || last.item_type !== 'text' || seenDM.has(String(last.item_id))) continue;
          if (Number(last.timestamp) / 1e6 < startedAt) { seenDM.add(String(last.item_id)); continue; }
          seenDM.add(String(last.item_id));
          await chrome.storage.local.set({ seenDM: [...seenDM].slice(-3000) });
          const history = items.filter(i => i.item_type === 'text').slice(0, 10).reverse().map(i => ({ me: String(i.user_id) === String(uid), text: i.text }));
          const who = th.users?.[0]?.username || '';
          const ai = await chrome.runtime.sendMessage({ cmd: 'ai', kind: 'dm', text: last.text, from: who, history });
          if (!ai?.ok || !ai.reply) { send({ cmd: 'log', item: { from: who, text: last.text, error: ai?.error || 'ما في رد', dmKind: true } }); continue; }
          await sleep(4000 + Math.random() * 6000);
          await sendDM({ thread: th.thread_id, text: ai.reply });
          await chrome.storage.local.set({ lastReplyAt: Date.now(), hourly: [...hourly, Date.now()] });
          send({ cmd: 'log', item: { from: who, text: last.text, dm: ai.reply, dmKind: true } });
          return send({ cmd: 'status', text: '✅ شغّال — آخر رد على رسالة @' + who });
        }
        await sleep(1500 + Math.random() * 1500);
      }

      const seen = new Set(st.seen);
      const feed = await ig(`/api/v1/feed/user/${uid}/?count=6`);
      for (const media of feed.items || []) {
        await sleep(1500 + Math.random() * 2000);
        const cm = await ig(`/api/v1/media/${media.pk}/comments/?can_support_threading=true&permalink_enabled=false`);
        const fresh = (cm.comments || []).filter(c => String(c.user?.pk) !== String(uid) && c.created_at >= startedAt && !seen.has(String(c.pk)));
        if (!fresh.length) continue;
        const c = fresh[fresh.length - 1]; // أقدم تعليق جديد
        seen.add(String(c.pk));
        await chrome.storage.local.set({ seen: [...seen].slice(-3000) });
        const ai = await chrome.runtime.sendMessage({ cmd: 'ai', text: c.text, from: c.user?.username });
        if (!ai?.ok || !ai.reply) { send({ cmd: 'log', item: { from: c.user?.username, text: c.text, error: ai?.error || 'ما في رد' } }); continue; }
        await sleep(4000 + Math.random() * 6000); // متل كأنو عم يكتب
        const body = new URLSearchParams({ comment_text: `@${c.user.username} ${ai.reply}`.slice(0, 2000), replied_to_comment_id: String(c.pk) });
        await ig(`/api/v1/web/comments/${media.pk}/add/`, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body });
        await chrome.storage.local.set({ lastReplyAt: Date.now(), hourly: [...hourly, Date.now()] });
        let dm = '';
        if (st.dmOnComment) {
          try {
            const ai2 = await chrome.runtime.sendMessage({ cmd: 'ai', kind: 'dm_first', text: c.text, from: c.user?.username });
            if (ai2?.ok && ai2.reply) { await sleep(5000 + Math.random() * 5000); await sendDM({ users: [c.user.pk], text: ai2.reply }); dm = ai2.reply; }
          } catch (e) { dm = '✗ ' + e.message; }
        }
        send({ cmd: 'log', item: { from: c.user?.username, text: c.text, reply: ai.reply, dm } });
        return send({ cmd: 'status', text: '✅ شغّال — آخر رد على @' + c.user?.username });
      }
      send({ cmd: 'status', text: '✅ شغّال — ما في تعليقات جديدة' });
    } catch (e) {
      send({ cmd: 'status', text: '✗ ' + e.message });
    } finally { busy = false; }
  }

  chrome.runtime.onMessage.addListener((m, _s, reply) => { if (m.cmd === 'cycle') { cycle(); reply({ ok: true }); } });
})();
