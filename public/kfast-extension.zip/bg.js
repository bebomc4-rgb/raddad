// K FAST AI — الخلفية: كل دقيقة بتطلب من تبويب إنستغرام يشيّك عالتعليقات، وبتجيب الرد من المنصة
const DEF = { server: 'https://k-fast-ai.pages.dev', token: '', enabled: false, perHour: 20 };
const get = () => chrome.storage.local.get(DEF);

chrome.runtime.onInstalled.addListener(() => chrome.alarms.create('cycle', { periodInMinutes: 1 }));
chrome.runtime.onStartup.addListener(() => chrome.alarms.create('cycle', { periodInMinutes: 1 }));

async function setStatus(text) { await chrome.storage.local.set({ status: text, statusAt: Date.now() }); }

chrome.alarms.onAlarm.addListener(async a => {
  if (a.name !== 'cycle') return;
  const s = await get();
  if (!s.enabled) return setStatus('⏸ مطفي');
  if (!s.token) return setStatus('✗ حط مفتاح الإضافة من صفحة "الرد على التعليقات"');
  const tabs = await chrome.tabs.query({ url: 'https://www.instagram.com/*' });
  if (!tabs.length) return setStatus('⚠️ افتح instagram.com بتبويب وخلّيه مفتوح');
  chrome.tabs.sendMessage(tabs[0].id, { cmd: 'cycle' }).catch(() => setStatus('⚠️ حدّث صفحة إنستغرام (F5)'));
});

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg.cmd === 'ai') {
    (async () => {
      const s = await get();
      try {
        const r = await fetch(s.server.replace(/\/$/, '') + '/meta/ext/reply', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + s.token },
          body: JSON.stringify({ text: msg.text, from: msg.from, platform: 'ig', kind: msg.kind || 'comment', history: msg.history || [] })
        });
        const d = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(d.error || 'المنصة ردّت ' + r.status);
        reply({ ok: true, reply: d.reply });
      } catch (e) { reply({ ok: false, error: e.message }); }
    })();
    return true;
  }
  if (msg.cmd === 'status') { setStatus(msg.text); }
  if (msg.cmd === 'log') {
    chrome.storage.local.get({ log: [] }).then(({ log }) => chrome.storage.local.set({ log: [{ at: Date.now(), ...msg.item }, ...log].slice(0, 40) }));
  }
});
