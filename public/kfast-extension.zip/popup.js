const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
async function draw() {
  const s = await chrome.storage.local.get({ server: 'https://k-fast-ai.pages.dev', token: '', enabled: false, perHour: 20, status: '', log: [], dmOnComment: true, dmReply: true });
  $('#en').checked = s.enabled; $('#tok').value = s.token; $('#srv').value = s.server; $('#ph').value = s.perHour; $('#dmc').checked = s.dmOnComment; $('#dmr').checked = s.dmReply;
  $('#st').textContent = s.status || (s.enabled ? 'عم يبلّش… (خلال دقيقة)' : '⏸ مطفي');
  $('#log').innerHTML = s.log.map(l => `<div class="log"><b>@${esc(l.from)}</b>: ${esc(l.text)}<br>${l.reply ? '↩️ ' + esc(l.reply) : ''}${l.dm ? '<br>📩 ' + esc(l.dm) : ''}${l.error ? `<span class="bad">✗ ${esc(l.error)}</span>` : ''}</div>`).join('');
}
$('#sv').onclick = async () => {
  const enabled = $('#en').checked;
  const prev = await chrome.storage.local.get({ enabled: false });
  const patch = { enabled, token: $('#tok').value.trim(), server: $('#srv').value.trim() || 'https://k-fast-ai.pages.dev', perHour: Math.min(60, Math.max(1, Number($('#ph').value) || 20)), dmOnComment: $('#dmc').checked, dmReply: $('#dmr').checked };
  if (enabled && !prev.enabled) patch.startedAt = 0; // بيبلّش من التعليقات الجديدة بس
  await chrome.storage.local.set(patch);
  chrome.alarms.create('cycle', { periodInMinutes: 1 });
  draw();
};
draw(); setInterval(draw, 3000);
